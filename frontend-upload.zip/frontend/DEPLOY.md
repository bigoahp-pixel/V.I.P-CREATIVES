# Deploy the V.I.P Creative Studio frontend

This folder is a standalone React/Vite portfolio. Its bundled gallery works without the Django backend. In standalone mode, the booking form opens the visitor's selected contact app (WhatsApp, phone, or email) with the booking details where supported; bookings are not sent to or stored by the studio. The staff dashboard, live gallery uploads, and server-side booking submissions require a deployed backend.

## Before deploying

1. Push the project to a Git repository. Keep `node_modules`, `dist`, and local `.env` files out of Git; the repository `.gitignore` handles these.
2. Choose either Vercel or Netlify below. Both providers build the frontend from this folder and publish the generated `dist` directory.
3. After the first deployment, open the deployed site and check the gallery, contact links, booking form, and (if enabled) `/admin`.

## Vercel

1. Import the repository in Vercel.
2. Set the project **Root Directory** to `frontend` (the folder containing this file).
3. Use **Install Command** `npm ci`, **Build Command** `npm run build`, and **Output Directory** `dist`.
4. Deploy. The included `vercel.json` routes `/admin` to the React app. No environment variable is needed for the standalone portfolio.

## Netlify

1. Import the repository in Netlify.
2. Set the **Base directory** to `frontend`, **Build command** to `npm run build`, and **Publish directory** to `dist`.
3. Deploy. Vite copies `public/_redirects` into `dist` to provide the single-page application fallback. No environment variable is needed for the standalone portfolio.

For a quick Netlify preview, run `npm ci` and `npm run build` in this folder, then deploy the generated `dist` folder.

## Optional Django API

To enable booking submissions, live gallery management, and the staff dashboard, deploy the Django backend separately and set `VITE_API_URL` in the hosting provider to the backend API root, for example `https://api.example.com/api`. Set it in the frontend project's build environment and rebuild/redeploy the frontend. Configure the backend's CORS and CSRF trusted origins for the exact deployed frontend domain. Keep email, WhatsApp, and Django secrets on the backend; never put them in `VITE_*` variables. The checked-in `.env.example` is only a local development example; do not use its localhost URL as a production setting.
