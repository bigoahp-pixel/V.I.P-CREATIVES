import { useEffect, useState } from "react";
import {
  ArrowDown, ArrowLeft, ArrowRight, ArrowUpRight, Aperture, Check, ChevronDown,
  Clock3, Menu, MessageCircle, X,
} from "lucide-react";

const API = (import.meta.env.VITE_API_URL || "").replace(/\/$/, "");
const WHATSAPP = "https://wa.me/211922865522";
const services = [
  "Wedding photography", "Birthday photography", "Portraits", "Graduation", "Events", "Fashion",
  "Family photography", "Commercial photography", "Cultural events", "Sports",
  "Real estate", "Photo editing", "Video production",
];
const defaultGalleryCategories = [
  { slug: "weddings", title: "Weddings & celebrations", service: "Wedding photography" },
  { slug: "portraits", title: "Portraits & personal stories", service: "Portraits" },
  { slug: "graduation", title: "Graduation & milestones", service: "Graduation" },
  { slug: "family", title: "Family & maternity", service: "Family photography" },
  { slug: "fashion", title: "Fashion & commercial", service: "Fashion" },
  { slug: "events", title: "Events, culture & film", service: "Events" },
  { slug: "birthdays", title: "Birthday celebrations", service: "Birthday photography" },
];
const featuredPortfolio = [
  { src: "/images/portrait-flower.jpeg", title: "A light of her own", kind: "Portraits", categories: ["portraits", "fashion"] },
  { src: "/images/graduation-pair.jpeg", title: "The next chapter", kind: "Graduation", categories: ["graduation", "events"] },
  { src: "/images/portrait-magenta.jpeg", title: "In full bloom", kind: "Fashion", categories: ["portraits", "fashion"] },
  { src: "/images/couple-session.jpeg", title: "A story, together", kind: "Couples", categories: ["weddings", "portraits"] },
  { src: "/images/fashion-session.jpeg", title: "Golden hour, always", kind: "Editorial", categories: ["fashion", "events"] },
  { src: "/images/maternity-portrait.jpeg", title: "Made of wonder", kind: "Family", categories: ["portraits", "family"] },
  { src: "/images/evening-portrait.jpeg", title: "After the light", kind: "Portraits", categories: ["portraits", "fashion"] },
  { src: "/images/studio-portrait.jpeg", title: "The beauty in stillness", kind: "Portraits", categories: ["portraits"] },
  { src: "/images/fashion-campaign.jpeg", title: "Soft power", kind: "Fashion", categories: ["fashion", "events"] },
  { src: "/images/graduation-celebration-pair.jpeg", title: "A milestone shared", kind: "Graduation", categories: ["graduation", "events"] },
  { src: "/images/graduation-white-suit.jpeg", title: "A proud new chapter", kind: "Graduation", categories: ["graduation"] },
  { src: "/images/graduation-class-of-2025.jpeg", title: "Class of 2025", kind: "Graduation", categories: ["graduation", "events"] },
  { src: "/images/graduation-caps.jpeg", title: "The moment it all lands", kind: "Graduation", categories: ["graduation"] },
  { src: "/images/fashion-white-editorial.jpeg", title: "Together, soon", kind: "Maternity", categories: ["family"] },
  { src: "/images/culture-pageant.jpeg", title: "A queen in her moment", kind: "Culture", categories: ["fashion", "events"] },
  { src: "/images/maternity-session.jpeg", title: "Growing together", kind: "Maternity", categories: ["weddings", "family"] },
  { src: "/images/family-session.jpeg", title: "All together, always", kind: "Family", categories: ["weddings", "family"] },
];
const suppliedPhotoGroups = [
  { kind: "Birthday", categories: ["birthdays", "weddings"], ids: ["3590-1a2d6fb0", "3589-28cd8ef7", "3592-43828b94", "3593-7b635399", "3578-87c17c1b", "3591-be1c9e6c", "2596-f9a0d4f4"] },
  { kind: "Wedding", categories: ["weddings", "portraits"], ids: ["4214-2838181a", "4213-aac139c9"] },
  { kind: "Graduation", categories: ["graduation", "events"], ids: ["0289-026d01d8", "0550-ab40e440", "0552-690f909c", "0558-69481a8e", "0561-399cf67b", "0287-7ff969fc"] },
  { kind: "Culture", categories: ["fashion", "events"], ids: ["6354-08fcb48b", "6351-0edef51d", "6086-1db01cff", "5579-032e19cb", "5605-03dbc2ef", "5606-4d16e62b", "5740-3f2441d8", "5743-5cf6d7a5", "0605-25bc8b3e"] },
  { kind: "Portrait", categories: ["portraits"], ids: ["6033-0ea87c89", "8564-0e689255", "9386-0ea40273", "6030-1878364d", "4412-0ede65cf", "9136-07f1606f", "9019-30ad6ef1", "6039-34c970b8", "9140-3e0b0331", "4415-6dbf850b", "2591-178a527b"] },
  { kind: "Fashion", categories: ["portraits", "fashion"], ids: ["2689-020a5e98", "8189-0231cb04", "9011-048c43d4", "1101-04b9ae82", "6344-05ad2d48", "9022-05bfc61e", "8510-1bc6d07b", "9020-128d8ea2", "9016-15804200", "9064-267aafa3", "9225-286ad686", "1094-2b687680", "0597-2c882700", "9219-465a42f7", "2621-5749616a", "5364-707efc67", "8500-7244f461", "2687-8ad05cc1", "3417-aeba9396", "2728-af678d85", "2690-bae83f72", "2619-f1cb1d5d", "2618-f2f9e604"] },
  { kind: "Events", categories: ["events"], ids: ["5550-0a531f58", "5583-0c9839a3", "5581-29ffd09d", "9008-3506fde2"] },
  { kind: "Birthday", categories: ["birthdays", "events"], ids: ["2247"] },
  { kind: "Graduation", categories: ["graduation", "events"], ids: ["0585", "0614", "2171", "GRAD_CS", "GRAD_D", "GRAD_MAROON", "GRAD_MAROON_FULL"] },
  { kind: "Culture", categories: ["fashion", "events"], ids: ["0661"] },
  { kind: "Portrait", categories: ["portraits", "fashion"], ids: ["2190", "0502", "0542", "0525", "0513", "0586", "0718", "1104", "0644", "0598", "0645", "1622", "1590", "0727", "2382", "1108", "2730", "2390", "1602", "1771", "2509"] },
  { kind: "Fashion", categories: ["portraits", "fashion"], ids: ["0573", "0577"] },
  { kind: "Events", categories: ["fashion", "events"], ids: ["0715"] },
];
const suppliedPhotos = suppliedPhotoGroups.flatMap(({ kind, categories, ids }) => ids.map((id, index) => ({
  src: `/images/IMG_${id}.jpeg`,
  title: `${kind} story ${String(index + 1).padStart(2, "0")}`,
  kind,
  categories,
})));
const portfolio = [...featuredPortfolio, ...suppliedPhotos];
function getHeroGalleryPhotos(livePhotos) {
  const maxHeroPhotos = 12;
  const allPhotos = [...livePhotos, ...portfolio];
  const selected = [];
  const selectedSources = new Set();
  const addPhoto = (photo) => {
    if (photo && selected.length < maxHeroPhotos && !selectedSources.has(photo.src)) {
      selectedSources.add(photo.src);
      selected.push(photo);
    }
  };

  ["weddings", "birthdays", "graduation", "family", "fashion", "events", "portraits"].forEach((category) => {
    allPhotos.filter((photo) => photo.categories.includes(category)).slice(0, 2).forEach(addPhoto);
  });
  allPhotos.forEach(addPhoto);
  return selected;
}

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const closeMenu = () => setMenuOpen(false);
  return (
    <header className="site-header">
      <a className="brand" href="#home" aria-label="V.I.P Creative Studio home" onClick={closeMenu}>
        <span className="brand-mark"><Aperture size={21} strokeWidth={1.5} /></span>
        <span className="brand-name"><span className="brand-title">V.I.P CREATIVE STUDIO</span><span className="brand-owner">Stephen Kuol</span></span>
      </a>
      <button className="menu-toggle" aria-label={menuOpen ? "Close navigation" : "Open navigation"} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>
        {menuOpen ? <X /> : <Menu />}
      </button>
      <nav className={menuOpen ? "main-nav open" : "main-nav"} aria-label="Main navigation">
        <a href="#work" onClick={closeMenu}>Selected work</a>
        <a href="#about" onClick={closeMenu}>Our studio</a>
        <a href="#services" onClick={closeMenu}>Services</a>
        {API && <a className="nav-staff" href="/admin" onClick={closeMenu}>Staff / Admin login <ArrowUpRight size={14} /></a>}
        <a className="nav-book" href="#booking" onClick={closeMenu}>Book a session <ArrowUpRight size={15} /></a>
      </nav>
    </header>
  );
}

function Gallery({ category, galleryCategories, galleryPhotos, onCategoryChange, onBookCategory }) {
  const [active, setActive] = useState(null);
  const allPhotos = [...portfolio, ...galleryPhotos];
  const filteredPortfolio = category === "all"
    ? allPhotos
    : allPhotos.filter((item) => item.categories.includes(category));
  useEffect(() => {
    if (active === null) return undefined;
    const previousFocus = document.activeElement;
    const onKeyDown = (event) => {
      if (event.key === "Escape") setActive(null);
      if (event.key === "ArrowRight") setActive((index) => (index + 1) % filteredPortfolio.length);
      if (event.key === "ArrowLeft") setActive((index) => (index + filteredPortfolio.length - 1) % filteredPortfolio.length);
      if (event.key === "Tab") {
        const focusable = document.querySelectorAll(".lightbox button");
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    };
    document.querySelector(".lightbox-close")?.focus();
    window.addEventListener("keydown", onKeyDown);
    return () => { window.removeEventListener("keydown", onKeyDown); previousFocus?.focus?.(); };
  }, [active, filteredPortfolio.length]);
  const selectCategory = (nextCategory) => {
    setActive(null);
    onCategoryChange(nextCategory);
  };
  return (
    <>
      <nav className="gallery-filters" aria-label="Filter gallery by category">
        <button className={`gallery-filter${category === "all" ? " active" : ""}`} type="button" aria-pressed={category === "all"} onClick={() => selectCategory("all")}>All work</button>
        {galleryCategories.map((item) => (
          <button className={`gallery-filter${category === item.slug ? " active" : ""}`} type="button" key={item.slug} aria-pressed={category === item.slug} onClick={() => selectCategory(item.slug)}>{item.title}</button>
        ))}
        {category !== "all" && <button className="button button-gold gallery-book" type="button" onClick={() => onBookCategory(category)}>Book this service <ArrowUpRight size={15} /></button>}
      </nav>
      <div className="gallery-grid">
        {filteredPortfolio.map((item, index) => (
          <button className={`gallery-item gallery-item-${index + 1}`} key={item.src} onClick={() => setActive(index)} aria-label={`View ${item.title}, ${item.kind}`}>
            <img src={item.src} alt={`${item.kind} photography by V.I.P Creative Studio`} loading="lazy" />
            <span className="gallery-caption"><span><small>{item.kind}</small><strong>{item.title}</strong></span><ArrowUpRight size={17} /></span>
          </button>
        ))}
      </div>
      {active !== null && (
        <div className="lightbox" role="dialog" aria-modal="true" aria-label={filteredPortfolio[active].title} onClick={() => setActive(null)}>
          <button className="lightbox-close" aria-label="Close image" onClick={() => setActive(null)}><X /></button>
          <button className="lightbox-arrow lightbox-prev" aria-label="Previous image" onClick={(event) => { event.stopPropagation(); setActive((active + filteredPortfolio.length - 1) % filteredPortfolio.length); }}><ArrowLeft /></button>
          <img src={filteredPortfolio[active].src} alt={`${filteredPortfolio[active].kind} photography by V.I.P Creative Studio`} onClick={(event) => event.stopPropagation()} />
          <button className="lightbox-arrow lightbox-next" aria-label="Next image" onClick={(event) => { event.stopPropagation(); setActive((active + 1) % filteredPortfolio.length); }}><ArrowRight /></button>
          <p>{filteredPortfolio[active].title} <span>— {filteredPortfolio[active].kind}</span></p>
        </div>
      )}
    </>
  );
}

function Field({ label, name, required = false, children, className = "" }) {
  return <label className={`form-field ${className}`}><span>{label}{required && <i> *</i>}</span>{children}</label>;
}

function getPreferredContactAction(payload) {
  const bookingDetails = [
    "Hello V.I.P Creative Studio, I would like to request a photography session.",
    `Name: ${payload.full_name}`,
    `Service: ${payload.service}`,
    `Preferred date: ${payload.appointment_date} at ${payload.appointment_time}`,
    `Location: ${payload.location || "Not specified"}`,
    `Budget: ${payload.budget || "Not specified"}`,
    `People: ${payload.people_count || "Not specified"}`,
    `Requirements: ${payload.requirements || "None"}`,
    `Phone: ${payload.phone}`,
    `Email: ${payload.email}`,
  ].join("\n");

  switch (payload.preferred_contact) {
    case "whatsapp":
      return {
        heading: "Continue in WhatsApp",
        label: "Open WhatsApp message",
        url: `${WHATSAPP}?text=${encodeURIComponent(bookingDetails)}`,
      };
    case "phone":
      return {
        heading: "Call the studio",
        label: "Call +211 922 865 522",
        url: "tel:+211922865522",
      };
    case "email":
      return {
        heading: "Compose an email",
        label: "Compose email to the studio",
        url: `mailto:Kuolstephen54@gmail.com?subject=${encodeURIComponent("Photography booking request")}&body=${encodeURIComponent(bookingDetails)}`,
      };
    default:
      throw new Error("Please choose a preferred contact method.");
  }
}

function BookingForm({ requestedService, onRequestedServiceChange }) {
  const [state, setState] = useState({ phase: "idle", notice: "", booking: null });
  const [dateMin] = useState(() => new Date().toLocaleDateString("en-CA", { timeZone: "Africa/Juba" }));
  const [idempotencyKey, setIdempotencyKey] = useState(() => crypto.randomUUID());

  async function submit(event) {
    event.preventDefault();
    if (state.phase === "sending") return;
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    setState({ phase: "sending", notice: "", booking: null });
    const formData = new FormData(form);
    const payload = Object.fromEntries(formData.entries());
    payload.people_count = payload.people_count ? Number(payload.people_count) : null;
    const contactAction = getPreferredContactAction(payload);
    const contactWindow = window.open("", "_blank");
    if (!API) {
      if (contactWindow) contactWindow.location.href = contactAction.url;
      setState({
        phase: "contact",
        notice: `Continue using your preferred contact method. This static portfolio does not submit or save bookings.`,
        booking: { action_url: contactAction.url, action_label: contactAction.label, action_heading: contactAction.heading },
      });
      form.reset();
      onRequestedServiceChange("");
      return;
    }
    try {
      const response = await fetch(`${API}/bookings/`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Idempotency-Key": idempotencyKey },
        body: JSON.stringify(payload),
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) {
        if (contactWindow) contactWindow.close();
        if (response.status === 429) throw new Error("We have received several requests from this connection. Please try again later or contact us on WhatsApp.");
        const firstError = Object.values(result).flat().find((value) => typeof value === "string");
        throw new Error(firstError || "Please check your details and try again.");
      }
      setState({
        phase: "success",
        notice: "Your request is safely with our studio. Your appointment is pending until we confirm it.",
        booking: { ...result, action_url: contactAction.url, action_label: contactAction.label },
      });
      setIdempotencyKey(crypto.randomUUID());
      form.reset();
      onRequestedServiceChange("");
      if (contactWindow) contactWindow.location.href = contactAction.url;
    } catch (error) {
      if (contactWindow && !contactWindow.closed) contactWindow.close();
      setState({ phase: "error", notice: error.message || "We could not confirm receipt. Please contact the studio directly.", booking: null });
    }
  }

  return (
    <div className="booking-layout">
      <div className="booking-copy">
        <p className="eyebrow"><span /> MAKE SOMETHING LAST</p>
        <h2>Let’s create a<br /><em>little magic.</em></h2>
        <p className="booking-intro">Tell us what you’re dreaming up. Share a few details and our team will be in touch to make it happen.</p>
        <div className="booking-promise"><span className="promise-icon"><Clock3 size={18} /></span><p><strong>Made personal, always.</strong><br />Every request is reviewed by our studio team. Your date is held only once we confirm it.</p></div>
        <a className="contact-link" href={WHATSAPP} target="_blank" rel="noreferrer"><MessageCircle size={17} /> Prefer a conversation? WhatsApp us <ArrowUpRight size={15} /></a>
      </div>
      <form className="booking-form" onSubmit={submit}>
        <div className="form-heading"><div><span className="form-step">01 / YOUR SESSION</span><h3>Booking request</h3></div><span className="required-note">* Required</span></div>
        <div className="form-grid">
          <Field label="Full name" name="full_name" required><input autoComplete="name" name="full_name" placeholder="Your name" minLength="2" maxLength="120" required /></Field>
          <Field label="Email address" name="email" required><input autoComplete="email" name="email" type="email" placeholder="you@example.com" maxLength="254" required /></Field>
          <Field label="Phone / WhatsApp" name="phone" required><input autoComplete="tel" name="phone" type="tel" placeholder="+211 922 865 522" aria-describedby="phone-format-help" maxLength="40" required /><small className="field-help" id="phone-format-help">Include your country code (start with + or 00). International spacing and punctuation are accepted.</small></Field>
          <Field label="Photography service" name="service" required><select name="service" value={requestedService} onChange={(event) => onRequestedServiceChange(event.target.value)} required><option value="" disabled>Choose a service</option>{services.map((service) => <option key={service}>{service}</option>)}</select><ChevronDown className="select-chevron" size={15} /></Field>
          <Field label="Preferred date" name="appointment_date" required><input name="appointment_date" type="date" min={dateMin} required /></Field>
          <Field label="Preferred time" name="appointment_time" required><input name="appointment_time" type="time" required /></Field>
          <Field label="Shoot or event location" name="location"><input name="location" placeholder="Venue, neighbourhood, or studio" maxLength="240" /></Field>
          <Field label="Estimated budget" name="budget"><input name="budget" placeholder="e.g. 150,000 SSP" maxLength="100" /></Field>
          <Field label="Number of people" name="people_count"><input name="people_count" type="number" min="1" max="500" placeholder="e.g. 2" /></Field>
          <Field label="Preferred contact" name="preferred_contact" required><small className="field-help">Choose WhatsApp to agree to receive booking updates through WhatsApp.</small><select name="preferred_contact" defaultValue="" required><option value="" disabled>Choose a contact method</option><option value="whatsapp">WhatsApp</option><option value="phone">Telephone</option><option value="email">Email</option></select><ChevronDown className="select-chevron" size={15} /></Field>
          <Field label="A little more about your vision" name="requirements" className="field-wide"><textarea name="requirements" rows="4" maxLength="2000" placeholder="Share any details that will help us bring your idea to life..." /></Field>
          <label className="honeypot" aria-hidden="true">Website<input name="website" tabIndex="-1" autoComplete="off" /></label>
        </div>
        {state.notice && <div className={`form-notice ${state.phase}`} role="status" aria-live="polite">
          {state.phase === "success" ? <Check size={18} /> : <span className="notice-mark">!</span>}
          <div><strong>{state.phase === "success" ? `Request received · ${state.booking.reference}` : state.phase === "contact" ? state.booking.action_heading : "A moment, please"}</strong><p>{state.notice}</p>
            {(state.phase === "contact" || state.phase === "success") && <a className="wa-followup" href={state.booking.action_url} target="_blank" rel="noreferrer">{state.booking.action_label} <ArrowUpRight size={14} /></a>}
            {state.phase === "success" && <div className="delivery-state">
              <span>Booking <b>Pending confirmation</b></span>
              <span>Email <b>{state.booking.owner_email_status === "sent" ? "Studio notified" : state.booking.owner_email_status === "failed" ? "Studio email failed; retry will be needed" : "Not configured"}</b></span>
              {state.booking.client_email_status !== "sent" && <span>Acknowledgement email <b>{state.booking.client_email_status === "failed" ? "Could not send" : "Not configured"}</b></span>}
              <span>WhatsApp <b>{state.booking.whatsapp_status === "accepted" ? "Accepted by provider, delivery pending" : state.booking.whatsapp_status === "failed" ? "Automatic message failed; manual enquiry is ready" : "Ready for you to review and send"}</b></span>
              <a className="wa-followup" href={state.booking.whatsapp_url} target="_blank" rel="noreferrer">Continue with WhatsApp <ArrowUpRight size={14} /></a>
            </div>}
          </div>
        </div>}
        <div className="submit-row"><p>Your appointment is not confirmed<br />until our team gets back to you.</p><button className="button button-gold" type="submit" disabled={state.phase === "sending"}>{state.phase === "sending" ? <><span className="spinner" /> Sending request…</> : <>Send booking request <ArrowUpRight size={16} /></>}</button></div>
      </form>
    </div>
  );
}

function AdminDashboard() {
  const [dateMin] = useState(() => new Date().toLocaleDateString("en-CA", { timeZone: "Africa/Juba" }));
  const [user, setUser] = useState(null);
  const [credentials, setCredentials] = useState({ username: "", password: "" });
  const [bookings, setBookings] = useState([]);
  const [categories, setCategories] = useState([]);
  const [galleryPhotos, setGalleryPhotos] = useState([]);
  const [staff, setStaff] = useState([]);
  const [categoryDraft, setCategoryDraft] = useState({ title: "", slug: "", service: "" });
  const [staffDraft, setStaffDraft] = useState({ username: "", email: "", password: "" });
  const [editingGalleryPhotoId, setEditingGalleryPhotoId] = useState(null);
  const [galleryPhotoDraft, setGalleryPhotoDraft] = useState({ title: "", category: "" });
  const [reschedules, setReschedules] = useState({});
  const [editingBookingId, setEditingBookingId] = useState(null);
  const [editDraft, setEditDraft] = useState(null);
  const [uploadingPhotos, setUploadingPhotos] = useState(false);
  const [filters, setFilters] = useState({ status: "", service: "", date_from: "", date_to: "" });
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  async function getCsrf() {
    const response = await fetch(`${API}/csrf/`, { credentials: "include" });
    if (!response.ok) throw new Error("Could not refresh the security token. Please reload and try again.");
    const result = await response.json();
    return result.csrfToken;
  }
  async function csrfFetch(url, options = {}) {
    const method = (options.method || "GET").toUpperCase();
    const requiresCsrf = !["GET", "HEAD", "OPTIONS"].includes(method);
    const send = async (token) => fetch(url, {
      credentials: "include",
      ...options,
      headers: {
        ...(options.headers || {}),
        ...(requiresCsrf ? { "X-CSRFToken": token } : {}),
      },
    });
    if (!requiresCsrf) return send("");
    let response = await send(await getCsrf());
    if (response.status === 403) response = await send(await getCsrf());
    return response;
  }
  async function loadBookings(activeFilters = filters) {
    setLoading(true);
    const query = new URLSearchParams(Object.fromEntries(Object.entries(activeFilters).filter(([, value]) => value)));
    const response = await fetch(`${API}/admin/bookings/?${query}`, { credentials: "include" });
    if (response.status === 401 || response.status === 403) { setUser(null); setLoading(false); return; }
    const result = await response.json();
    setBookings(Array.isArray(result) ? result : result.results || []);
    setLoading(false);
  }
  async function adminRequest(path, options = {}) {
    const response = await csrfFetch(`${API}${path}`, {
      ...options,
      headers: {
        ...(options.body && !(options.body instanceof FormData) ? { "Content-Type": "application/json" } : {}),
        ...(options.headers || {}),
      },
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.detail || (response.status === 403 ? "Your session may have expired. Refresh the page and sign in again." : JSON.stringify(result)) || "The request could not be completed.");
    return result;
  }
  async function loadManagement(isSuperuser = user?.is_superuser) {
    try {
      const [categoryRows, photoRows] = await Promise.all([
        adminRequest("/admin/gallery/categories/"),
        adminRequest("/admin/gallery/photos/"),
      ]);
      setCategories(categoryRows);
      setGalleryPhotos(photoRows);
      if (isSuperuser) setStaff(await adminRequest("/admin/staff/"));
    } catch (error) {
      setMessage(error.message || "Could not load studio management data.");
    }
  }
  async function checkSession() {
    const response = await csrfFetch(`${API}/admin/logout/`, { method: "POST" });
    if (!response.ok) throw new Error("Could not reset the previous admin session. Reload and try again.");
  }
  useEffect(() => { checkSession().catch(() => setMessage("Could not connect to the studio booking server.")); }, []);
  async function signIn(event) {
    event.preventDefault();
    try {
      const response = await csrfFetch(`${API}/admin/login/`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(credentials),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.detail || "Sign in failed.");
      await getCsrf();
      setCredentials({ username: "", password: "" });
      setUser(result); setMessage(""); await loadBookings(); await loadManagement(result.is_superuser);
    } catch (error) { setMessage(error.message); }
  }
  async function updateBooking(id, patch) {
    try {
      const updated = await adminRequest(`/admin/bookings/${id}/`, {
        method: "PATCH",
        body: JSON.stringify(patch),
      });
      setBookings((current) => current.map((booking) => booking.id === id ? updated : booking));
      if (patch.status && patch.status !== "pending") {
        setMessage(`Booking ${updated.reference} updated. Client notice — email: ${updated.status_email_status}; WhatsApp: ${updated.status_whatsapp_status}.`);
      } else {
        setMessage(`Booking ${updated.reference} updated.`);
      }
      if (patch.appointment_date || patch.appointment_time) {
        setReschedules((current) => ({ ...current, [id]: { appointment_date: updated.appointment_date, appointment_time: updated.appointment_time.slice(0, 5) } }));
      }
      return updated;
    } catch (error) {
      setMessage(error.message || "Could not update this booking.");
      return null;
    }
  }
  async function retryEmail(id) {
    try {
      await adminRequest(`/admin/bookings/${id}/retry-email/`, { method: "POST" });
      setMessage("Email retry attempted.");
      await loadBookings();
    } catch (error) { setMessage(error.message || "Email retry failed."); }
  }
  async function retryStatusNotification(id) {
    try {
      const result = await adminRequest(`/admin/bookings/${id}/retry-status-notification/`, { method: "POST" });
      setBookings((current) => current.map((booking) => booking.id === id ? { ...booking, ...result } : booking));
      setMessage(`Status notice attempt finished. Email: ${result.status_email_status}; WhatsApp: ${result.status_whatsapp_status}.`);
    } catch (error) { setMessage(error.message); }
  }
  async function signOut() {
    try {
      await csrfFetch(`${API}/admin/logout/`, { method: "POST" });
      setUser(null); setBookings([]); setCredentials({ username: "", password: "" });
    } catch (error) { setMessage(error.message); }
  }
  async function saveCategory(event, category) {
    event.preventDefault();
    try {
      await adminRequest(`/admin/gallery/categories/${category.slug}/`, {
        method: "PATCH",
        body: JSON.stringify({ title: category.title, service: category.service }),
      });
      setMessage(`Gallery category “${category.title}” saved.`);
      await loadManagement();
    } catch (error) { setMessage(error.message); }
  }
  async function createCategory(event) {
    event.preventDefault();
    try {
      await adminRequest("/admin/gallery/categories/", {
        method: "POST",
        body: JSON.stringify(categoryDraft),
      });
      setCategoryDraft({ title: "", slug: "", service: "" });
      setMessage("Gallery category added.");
      await loadManagement();
    } catch (error) { setMessage(error.message); }
  }
  async function deleteGalleryCategory(category) {
    if (!window.confirm(`Delete the “${category.title}” category? Categories with photos must be emptied first.`)) return;
    try {
      await adminRequest(`/admin/gallery/categories/${category.slug}/`, { method: "DELETE" });
      setMessage(`Deleted the “${category.title}” gallery category.`);
      await loadManagement();
    } catch (error) { setMessage(error.message); }
  }
  async function createStaff(event) {
    event.preventDefault();
    try {
      const created = await adminRequest("/admin/staff/", {
        method: "POST",
        body: JSON.stringify(staffDraft),
      });
      setStaffDraft({ username: "", email: "", password: "" });
      setMessage(`Staff account ${created.username} created.`);
      await loadManagement();
    } catch (error) { setMessage(error.message); }
  }
  async function uploadGalleryPhotos(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const files = form.elements.images.files;
    if (!files.length) {
      setMessage("Choose at least one photo to upload.");
      return;
    }
    const data = new FormData();
    data.append("category", form.elements.category.value);
    for (const file of files) data.append("images", file);
    setUploadingPhotos(true);
    try {
      const uploaded = await adminRequest("/admin/gallery/photos/", { method: "POST", body: data });
      form.reset();
      setMessage(`${uploaded.length} photo${uploaded.length === 1 ? "" : "s"} added to the public gallery.`);
      await loadManagement();
    } catch (error) { setMessage(error.message); }
    finally { setUploadingPhotos(false); }
  }
  async function deleteGalleryPhoto(photo) {
    if (!window.confirm(`Remove “${photo.title}” from the public gallery?`)) return;
    try {
      await adminRequest(`/admin/gallery/photos/${photo.id}/`, { method: "DELETE" });
      setMessage(`Removed “${photo.title}” from the gallery.`);
      await loadManagement();
    } catch (error) { setMessage(error.message); }
  }
  function startGalleryPhotoEdit(photo) {
    setEditingGalleryPhotoId(photo.id);
    setGalleryPhotoDraft({ title: photo.title, category: photo.category });
  }
  async function saveGalleryPhoto(event, photo) {
    event.preventDefault();
    const image = event.currentTarget.elements.image.files[0];
    const body = new FormData();
    body.append("title", galleryPhotoDraft.title);
    body.append("category", galleryPhotoDraft.category);
    if (image) body.append("image", image);
    try {
      await adminRequest(`/admin/gallery/photos/${photo.id}/`, { method: "PATCH", body });
      setEditingGalleryPhotoId(null);
      setMessage(`Saved changes to “${galleryPhotoDraft.title}”.`);
      await loadManagement();
    } catch (error) { setMessage(error.message); }
  }
  function startBookingEdit(booking) {
    setEditingBookingId(booking.id);
    setEditDraft({
      full_name: booking.full_name,
      email: booking.email,
      phone: booking.phone,
      service: booking.service,
      appointment_date: booking.appointment_date,
      appointment_time: booking.appointment_time.slice(0, 5),
      location: booking.location || "",
      budget: booking.budget || "",
      people_count: booking.people_count || "",
      preferred_contact: booking.preferred_contact,
      requirements: booking.requirements || "",
      internal_notes: booking.internal_notes || "",
    });
  }
  function updateEditDraft(event) {
    const { name, value } = event.target;
    setEditDraft((current) => ({ ...current, [name]: value }));
  }
  async function saveBookingEdit(event, bookingId) {
    event.preventDefault();
    const saved = await updateBooking(bookingId, {
      ...editDraft,
      people_count: editDraft.people_count === "" ? null : Number(editDraft.people_count),
    });
    if (saved) {
      setEditingBookingId(null);
      setEditDraft(null);
    }
  }
  async function deleteBooking(booking) {
    if (!window.confirm(`Permanently delete booking ${booking.reference} for ${booking.full_name}? This cannot be undone.`)) return;
    try {
      await adminRequest(`/admin/bookings/${booking.id}/`, { method: "DELETE" });
      setBookings((current) => current.filter((item) => item.id !== booking.id));
      setMessage(`Booking ${booking.reference} was deleted.`);
      if (editingBookingId === booking.id) {
        setEditingBookingId(null);
        setEditDraft(null);
      }
    } catch (error) { setMessage(error.message); }
  }
  function updateStatus(booking, status) {
    const label = status === "confirmed" ? "approve" : "decline";
    if (!window.confirm(`Are you sure you want to ${label} booking ${booking.reference}? The client will be notified through configured channels.`)) return;
    updateBooking(booking.id, { status });
  }
  function saveReschedule(booking) {
    const reschedule = reschedules[booking.id] || {
      appointment_date: booking.appointment_date,
      appointment_time: booking.appointment_time.slice(0, 5),
    };
    updateBooking(booking.id, reschedule);
  }
  function statusWhatsAppLink(booking) {
    const outcome = booking.status === "confirmed" ? "approved" : booking.status === "cancelled" ? "declined" : booking.status;
    const text = `Hello ${booking.full_name}, your V.I.P Creative Studio booking request ${booking.reference} has been ${outcome}. Appointment: ${booking.appointment_date} at ${booking.appointment_time.slice(0, 5)}. Service: ${booking.service}.`;
    return `https://wa.me/${booking.phone.replace(/\D/g, "")}?text=${encodeURIComponent(text)}`;
  }

  return (
    <main className="admin-shell">
      <div className="admin-top"><a className="brand" href="/"><span className="brand-mark"><Aperture size={21} /></span><span className="brand-name">V.I.P <span>STUDIO ADMIN</span></span></a><a href="/">← Return to studio</a></div>
      {!user ? <form className="admin-login" onSubmit={signIn}><span className="form-step">PRIVATE STUDIO ACCESS</span><h1>Welcome back.</h1><p>Sign in with your studio staff account to manage booking requests.</p>
        <Field label="Username" name="username" required><input autoComplete="username" value={credentials.username} onChange={(event) => setCredentials({ ...credentials, username: event.target.value })} required /></Field>
        <Field label="Password" name="password" required><input type="password" autoComplete="current-password" value={credentials.password} onChange={(event) => setCredentials({ ...credentials, password: event.target.value })} required /></Field>
        {message && <p className="admin-message" role="alert">{message}</p>}<button className="button button-gold" type="submit">Sign in <ArrowUpRight size={16} /></button>
      </form> : <section className="admin-content"><div className="admin-heading"><div><span className="form-step">STUDIO MANAGEMENT</span><h1>Booking requests</h1><p>Welcome, {user.username}. Every new appointment begins pending.</p></div><div className="admin-actions"><a className="button button-outline" href={`${API}/admin/bookings/export/`} target="_blank" rel="noreferrer">Export CSV <ArrowUpRight size={15} /></a><button className="button button-outline" onClick={signOut}>Sign out</button></div></div>
        <div className="admin-filters"><select aria-label="Filter by status" value={filters.status} onChange={(e) => setFilters({ ...filters, status: e.target.value })}><option value="">All statuses</option><option value="pending">Pending</option><option value="confirmed">Confirmed</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option></select><select aria-label="Filter by service" value={filters.service} onChange={(e) => setFilters({ ...filters, service: e.target.value })}><option value="">All services</option>{services.map((service) => <option key={service}>{service}</option>)}</select><input aria-label="Appointments from" type="date" value={filters.date_from} onChange={(e) => setFilters({ ...filters, date_from: e.target.value })} /><input aria-label="Appointments to" type="date" value={filters.date_to} onChange={(e) => setFilters({ ...filters, date_to: e.target.value })} /><button className="button button-gold" onClick={() => loadBookings()}>Apply filters</button></div>
        {message && <p className="admin-message" role="status">{message}</p>}
        <section className="management-section"><div className="management-title"><span className="form-step">PUBLIC PORTFOLIO</span><h2>Gallery categories</h2><p>Changes are reflected on the studio website.</p></div>
          <div className="management-grid">{categories.map((category) => <form className="management-card" key={category.slug} onSubmit={(event) => saveCategory(event, category)}>
            <label>Category title<input value={category.title} maxLength="80" onChange={(event) => setCategories((current) => current.map((item) => item.slug === category.slug ? { ...item, title: event.target.value } : item))} required /></label>
            <label>Booking service<select value={category.service || ""} onChange={(event) => setCategories((current) => current.map((item) => item.slug === category.slug ? { ...item, service: event.target.value } : item))}><option value="">No linked service</option>{services.map((service) => <option key={service}>{service}</option>)}</select></label>
            <div className="management-card-actions"><button className="button button-outline" type="submit">Save edits</button><button className="text-button" type="button" onClick={() => deleteGalleryCategory(category)}>Delete category</button></div>
          </form>)}
            <form className="management-card" onSubmit={createCategory}><strong>Add category</strong><label>Category title<input value={categoryDraft.title} maxLength="80" onChange={(event) => setCategoryDraft({ ...categoryDraft, title: event.target.value })} required /></label><label>URL slug (optional)<input value={categoryDraft.slug} maxLength="64" pattern="[a-zA-Z0-9-]*" placeholder="generated-from-title" onChange={(event) => setCategoryDraft({ ...categoryDraft, slug: event.target.value })} /></label><label>Booking service<select value={categoryDraft.service} onChange={(event) => setCategoryDraft({ ...categoryDraft, service: event.target.value })}><option value="">No linked service</option>{services.map((service) => <option key={service}>{service}</option>)}</select></label><button className="button button-gold" type="submit">Add category</button></form>
          </div>
        </section>
        <section className="management-section"><div className="management-title"><span className="form-step">PHOTO LIBRARY</span><h2>Upload gallery photos</h2><p>Choose a category and upload JPEG, PNG, or WebP photos (up to 20 files, 10 MB each). Edit, replace, or delete uploaded photos at any time.</p></div>
          {categories.length ? <form className="gallery-upload-form" onSubmit={uploadGalleryPhotos}>
            <label>Gallery category<select name="category" required defaultValue=""><option value="" disabled>Choose a category</option>{categories.map((category) => <option value={category.slug} key={category.slug}>{category.title}</option>)}</select></label>
            <label>Photo files<input name="images" type="file" accept="image/jpeg,image/png,image/webp" multiple required /></label>
            <button className="button button-gold" type="submit" disabled={uploadingPhotos}>{uploadingPhotos ? "Uploading…" : "Upload photos"} <ArrowUpRight size={15} /></button>
          </form> : <p className="admin-empty">Add a gallery category before uploading photos.</p>}
          {galleryPhotos.length > 0 && <div className="uploaded-photo-grid">{galleryPhotos.map((photo) => <article className="uploaded-photo-card" key={photo.id}>
            <img src={photo.image_url} alt={`${photo.title} in ${photo.category_title}`} loading="lazy" />
            {editingGalleryPhotoId === photo.id ? <form className="uploaded-photo-edit" onSubmit={(event) => saveGalleryPhoto(event, photo)}>
              <label>Photo title<input value={galleryPhotoDraft.title} maxLength="120" onChange={(event) => setGalleryPhotoDraft({ ...galleryPhotoDraft, title: event.target.value })} required /></label>
              <label>Gallery category<select value={galleryPhotoDraft.category} onChange={(event) => setGalleryPhotoDraft({ ...galleryPhotoDraft, category: event.target.value })} required>{categories.map((category) => <option value={category.slug} key={category.slug}>{category.title}</option>)}</select></label>
              <label>Replace image (optional)<input name="image" type="file" accept="image/jpeg,image/png,image/webp" /></label>
              <div className="uploaded-photo-actions"><button className="button button-gold" type="submit">Save photo</button><button className="text-button" type="button" onClick={() => setEditingGalleryPhotoId(null)}>Cancel</button></div>
            </form> : <div><strong>{photo.title}</strong><span>{photo.category_title}</span><div className="uploaded-photo-actions"><button className="text-button" type="button" onClick={() => startGalleryPhotoEdit(photo)}>Edit photo</button><button className="text-button" type="button" onClick={() => deleteGalleryPhoto(photo)}>Delete photo</button></div></div>}
          </article>)}</div>}
        </section>
        {user.is_superuser && <section className="management-section"><div className="management-title"><span className="form-step">TEAM ACCESS</span><h2>Studio staff</h2><p>Staff accounts can manage bookings. Passwords must meet Django’s configured security rules.</p></div>
          <div className="staff-list">{staff.map((member) => <div className="staff-row" key={member.id}><strong>{member.username}</strong><span>{member.email || "No email"}</span><span>{member.is_active ? "Active" : "Inactive"}{member.is_superuser ? " · Superuser" : " · Staff"}</span></div>)}</div>
          <form className="staff-create" onSubmit={createStaff}><Field label="Username" name="staff_username" required><input value={staffDraft.username} maxLength="150" onChange={(event) => setStaffDraft({ ...staffDraft, username: event.target.value })} required /></Field><Field label="Email" name="staff_email"><input type="email" value={staffDraft.email} onChange={(event) => setStaffDraft({ ...staffDraft, email: event.target.value })} /></Field><Field label="Temporary password" name="staff_password" required><input type="password" autoComplete="new-password" value={staffDraft.password} onChange={(event) => setStaffDraft({ ...staffDraft, password: event.target.value })} minLength="8" required /></Field><button className="button button-gold" type="submit">Add staff member</button></form>
        </section>}
        {loading ? <div className="admin-empty">Loading requests…</div> : bookings.length === 0 ? <div className="admin-empty">No booking requests match these filters.</div> : <div className="booking-list">{bookings.map((booking) => <article className="admin-card" key={booking.id}>
          <div className="admin-card-head"><div><span className="booking-ref">{booking.reference}</span><h2>{booking.full_name}</h2></div><div className="booking-card-actions"><span className={`status-badge ${booking.status}`}>{booking.status}</span><button className="text-button" type="button" onClick={() => editingBookingId === booking.id ? (setEditingBookingId(null), setEditDraft(null)) : startBookingEdit(booking)}>{editingBookingId === booking.id ? "Cancel edit" : "Edit booking"}</button><button className="text-button booking-delete" type="button" onClick={() => deleteBooking(booking)}>Delete</button></div></div>
          {editingBookingId === booking.id && editDraft && <form className="admin-edit-form" onSubmit={(event) => saveBookingEdit(event, booking.id)}><div className="admin-edit-grid">
            <Field label="Full name" name="full_name" required><input name="full_name" value={editDraft.full_name} onChange={updateEditDraft} minLength="2" maxLength="120" required /></Field>
            <Field label="Email address" name="email" required><input name="email" type="email" value={editDraft.email} onChange={updateEditDraft} maxLength="254" required /></Field>
            <Field label="Phone / WhatsApp" name="phone" required><input name="phone" type="tel" value={editDraft.phone} onChange={updateEditDraft} maxLength="40" required /></Field>
            <Field label="Photography service" name="service" required><select name="service" value={editDraft.service} onChange={updateEditDraft} required>{services.map((service) => <option key={service}>{service}</option>)}</select></Field>
            <Field label="Appointment date" name="appointment_date" required><input name="appointment_date" type="date" min={dateMin} value={editDraft.appointment_date} onChange={updateEditDraft} required /></Field>
            <Field label="Appointment time" name="appointment_time" required><input name="appointment_time" type="time" value={editDraft.appointment_time} onChange={updateEditDraft} required /></Field>
            <Field label="Location" name="location"><input name="location" value={editDraft.location} onChange={updateEditDraft} maxLength="240" /></Field>
            <Field label="Estimated budget" name="budget"><input name="budget" value={editDraft.budget} onChange={updateEditDraft} maxLength="100" /></Field>
            <Field label="Number of people" name="people_count"><input name="people_count" type="number" min="1" max="500" value={editDraft.people_count} onChange={updateEditDraft} /></Field>
            <Field label="Preferred contact" name="preferred_contact" required><select name="preferred_contact" value={editDraft.preferred_contact} onChange={updateEditDraft} required><option value="whatsapp">WhatsApp</option><option value="phone">Telephone</option><option value="email">Email</option></select></Field>
            <Field label="Internal notes" name="internal_notes"><textarea name="internal_notes" value={editDraft.internal_notes} onChange={updateEditDraft} /></Field>
            <Field label="Client requirements" name="requirements"><textarea name="requirements" maxLength="2000" value={editDraft.requirements} onChange={updateEditDraft} /></Field>
          </div><div className="admin-edit-actions"><button className="button button-gold" type="submit">Save booking changes</button><button className="button button-outline" type="button" onClick={() => { setEditingBookingId(null); setEditDraft(null); }}>Cancel</button></div></form>}
          <div className="admin-detail-grid"><span><small>Service</small>{booking.service}</span><span><small>Appointment</small>{booking.appointment_date} · {booking.appointment_time.slice(0, 5)}</span><span><small>Phone / WhatsApp</small><a href={`https://wa.me/${booking.phone.replace(/\D/g, "")}`} target="_blank" rel="noreferrer">{booking.phone}</a></span><span><small>Email</small><a href={`mailto:${booking.email}`}>{booking.email}</a></span><span><small>Location</small>{booking.location || "Not provided"}</span><span><small>Budget</small>{booking.budget || "Not provided"}</span><span><small>People</small>{booking.people_count || "Not provided"}</span><span><small>Preferred contact</small>{booking.preferred_contact}</span><span><small>New booking notifications</small>Studio email: {booking.owner_email_status} · Client email: {booking.client_email_status} · Owner WhatsApp: {booking.whatsapp_status}</span><span className="status-notification"><small>Decision / reschedule notice to client</small>Email: {booking.status_email_status} · WhatsApp: {booking.status_whatsapp_status}<em>WhatsApp “accepted” means queued by Meta, not confirmed delivered. Delivery status appears after a webhook callback.</em></span></div>
          {booking.requirements && <p className="admin-requirements">{booking.requirements}</p>}
          <div className="admin-card-foot"><label>Status <select value={booking.status} onChange={(e) => updateBooking(booking.id, { status: e.target.value })}><option value="pending">Pending</option><option value="confirmed">Confirmed</option><option value="completed">Completed</option><option value="cancelled">Declined / Cancelled</option></select></label>{booking.status === "pending" && <><button className="button button-gold" type="button" onClick={() => updateStatus(booking, "confirmed")}>Approve appointment</button><button className="button button-outline" type="button" onClick={() => updateStatus(booking, "cancelled")}>Decline request</button></>}<label className="notes-field">Internal notes <input defaultValue={booking.internal_notes} placeholder="Private studio notes" onBlur={(e) => e.target.value !== booking.internal_notes && updateBooking(booking.id, { internal_notes: e.target.value })} /></label><label>Reschedule date <input type="date" min={dateMin} value={reschedules[booking.id]?.appointment_date ?? booking.appointment_date} onChange={(e) => setReschedules((current) => ({ ...current, [booking.id]: { appointment_date: e.target.value, appointment_time: current[booking.id]?.appointment_time ?? booking.appointment_time.slice(0, 5) } }))} /></label><label>Time <input type="time" value={reschedules[booking.id]?.appointment_time ?? booking.appointment_time.slice(0, 5)} onChange={(e) => setReschedules((current) => ({ ...current, [booking.id]: { appointment_date: current[booking.id]?.appointment_date ?? booking.appointment_date, appointment_time: e.target.value } }))} /></label><button className="button button-outline" type="button" onClick={() => saveReschedule(booking)}>Save reschedule</button>{["pending", "failed", "not_configured"].includes(booking.owner_email_status) || ["pending", "failed", "not_configured"].includes(booking.client_email_status) ? <button className="text-button" onClick={() => retryEmail(booking.id)}>Retry booking email <ArrowUpRight size={14} /></button> : null}{["failed", "not_configured"].includes(booking.status_email_status) || ["failed", "not_configured"].includes(booking.status_whatsapp_status) ? <button className="text-button" onClick={() => retryStatusNotification(booking.id)}>Retry decision notice <ArrowUpRight size={14} /></button> : null}<a className="text-button" href={statusWhatsAppLink(booking)} target="_blank" rel="noreferrer">Prepare WhatsApp update <ArrowUpRight size={14} /></a></div>
        </article>)}</div>}
      </section>}
    </main>
  );
}

function Site() {
  const [year] = useState(new Date().getFullYear());
  const [selectedBookingService, setSelectedBookingService] = useState("");
  const [galleryCategories, setGalleryCategories] = useState(defaultGalleryCategories);
  const [galleryPhotos, setGalleryPhotos] = useState([]);
  const [galleryCategory, setGalleryCategory] = useState("all");
  useEffect(() => {
    if (!API) return;
    Promise.all([
      fetch(`${API}/gallery/categories/`).then((response) => {
        if (!response.ok) throw new Error(`Category request failed (${response.status}).`);
        return response.json();
      }),
      fetch(`${API}/gallery/photos/`).then((response) => {
        if (!response.ok) throw new Error(`Photo request failed (${response.status}).`);
        return response.json();
      }),
    ])
      .then(([categories, photos]) => {
        if (Array.isArray(categories) && categories.length) setGalleryCategories(categories);
        if (Array.isArray(photos)) setGalleryPhotos(photos.map((photo) => ({
          id: photo.id,
          src: photo.image_url,
          title: photo.title,
          kind: photo.category_title,
          categories: [photo.category],
        })));
      })
      .catch((error) => console.error("Could not load live gallery content.", error));
  }, []);
  const showServiceGallery = (item) => {
    setGalleryCategory(item.slug);
    document.getElementById("work")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };
  const bookGalleryCategory = (category) => {
    const service = galleryCategories.find((item) => item.slug === category)?.service;
    if (service) setSelectedBookingService(service);
    document.getElementById("booking")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };
  const selectedCategory = galleryCategories.find((item) => item.slug === galleryCategory);
  const heroPhotos = getHeroGalleryPhotos(galleryPhotos);
  return (
    <>
      <Header />
      <main>
        <section className="hero" id="home">
          <div className="hero-image" role="img" aria-label="Blurred collage of wedding, birthday, graduation, fashion, family, event, and portrait photography">
            <div className="hero-collage">
              {heroPhotos.map((photo, index) => <img key={photo.src} src={photo.src} alt="" fetchpriority={index === 0 ? "high" : "low"} decoding="async" />)}
            </div>
          </div>
          <div className="hero-shade" />
          <div className="hero-content"><p className="eyebrow"><span /> JUBA, SOUTH SUDAN · EST. WITH PURPOSE</p><h1><span className="hero-title-line">Every frame</span><span className="hero-title-line">holds a <em>feeling.</em></span></h1><p className="hero-subtitle">We make photographs that feel like you — honest, soulful, and impossible to forget.</p><a className="button button-gold" href="#work">Explore our work <ArrowDown size={15} /></a></div>
          <div className="hero-index"><span>01</span><span className="index-line" /><span>{String(portfolio.length).padStart(2, "0")}</span></div>
          <div className="hero-side-note">LET LIGHT LEADS THE LENS</div>
          <div className="hero-bottom"><span>PORTRAITURE · WEDDINGS · FILM</span><span>06° 48′ 00″ N &nbsp; 31° 34′ 00″ E</span></div>
        </section>

        <section className="intro section-pad" id="about"><div className="section-label"><span>01</span><span className="label-rule" /> THE STUDIO</div><div className="intro-content"><h2>Not just how it<br />looked. <em>How it felt.</em></h2><div className="intro-text"><p>Some moments deserve more than a photograph. They deserve to be remembered exactly as they were felt — with all their warmth, wildness, and wonderful imperfection.</p><p>From our home in Juba, we make considered imagery for people with a story to tell. Yours is where we begin.</p><a href="#booking" className="text-link">Come tell us yours <ArrowUpRight size={15} /></a></div></div></section>

        <section className="artist-feature section-pad" aria-labelledby="artist-title">
          <div className="artist-portrait">
            <img src="/images/stephen-kuol-portrait.jpeg" alt="Stephen Kuol, photographer at V.I.P Creative Studio" loading="lazy" />
            <span className="artist-photo-caption">THE PERSON BEHIND THE LENS</span>
          </div>
          <div className="artist-copy">
            <div className="section-label"><span className="label-rule" /> MEET THE PHOTOGRAPHER</div>
            <h2 id="artist-title">Every story<br />starts with <em>seeing.</em></h2>
            <p>I'm Stephen Kuol, the eye and heart behind V.I.P Creative Studio. I believe the best photographs don't just show you how a moment looked — they bring you back to how it felt.</p>
            <p>From Juba, I create honest, thoughtful portraits and stories made to stay with you.</p>
            <div className="artist-signature"><span>STEPHEN KUOL</span><span>FOUNDER · PHOTOGRAPHER</span></div>
            <a href="#booking" className="text-link">Let’s create something together <ArrowUpRight size={15} /></a>
            <div className="artist-contacts" aria-label="Stephen Kuol contact and social links">
              <span className="artist-contacts-label">CONNECT WITH STEPHEN</span>
              <div>
                <a href={WHATSAPP} target="_blank" rel="noreferrer">WhatsApp <ArrowUpRight size={13} /></a>
                <a href="mailto:Kuolstephen54@gmail.com" aria-label="Email Stephen Kuol">Kuolstephen54@gmail.com <ArrowUpRight size={13} /></a>
                <a href="https://www.tiktok.com/@kuolvip?is_from_webapp=1&amp;sender_device=pc" target="_blank" rel="noreferrer">TikTok <ArrowUpRight size={13} /></a>
                <a href="https://web.facebook.com/kuollonydeang/reels/" target="_blank" rel="noreferrer">Facebook <ArrowUpRight size={13} /></a>
              </div>
            </div>
          </div>
        </section>

        <section className="work section-pad" id="work"><div className="section-top"><div><div className="section-label"><span>02</span><span className="label-rule" /> {galleryCategory === "all" ? "A FEW FAVOURITES" : "SELECTED CATEGORY"}</div><h2>{galleryCategory === "all" ? <>Made of <em>moments.</em></> : <em>{selectedCategory?.title || "Selected category"}</em>}</h2></div><p>{galleryCategory === "all" ? <>A little glimpse into the people, places<br />and stories we’ve been lucky to capture.</> : <>A closer look at moments captured<br />by V.I.P Creative Studio.</>}</p></div><Gallery category={galleryCategory} galleryCategories={galleryCategories} galleryPhotos={galleryPhotos} onCategoryChange={setGalleryCategory} onBookCategory={bookGalleryCategory} /></section>

        <section className="services section-pad" id="services"><div className="section-label"><span>03</span><span className="label-rule" /> WHAT WE DO</div><div className="services-heading"><h2>Here for every<br /><em>kind of becoming.</em></h2><p>Big days, new beginnings, and all the in-between. Let’s make a little something beautiful.</p></div>        <div className="service-list">{galleryCategories.map((item, index) => <button type="button" className="service-row" key={item.slug} aria-label={`View ${item.title} gallery`} onClick={() => showServiceGallery(item)}><span className="service-number">{String(index + 1).padStart(2, "0")}</span><span>{item.title}</span><ArrowUpRight size={17} /></button>)}</div></section>

        <section className="booking-section section-pad" id="booking"><div className="section-label"><span>04</span><span className="label-rule" /> YOUR STORY, NEXT</div><BookingForm requestedService={selectedBookingService} onRequestedServiceChange={setSelectedBookingService} /></section>

        <section className="visit-section"><div className="visit-copy"><p className="eyebrow"><span /> FIND YOUR WAY TO US</p><h2>Somewhere in<br /><em>the heart of Juba.</em></h2><p>Thongping, Suk Wewe, near the Red Cross Main Branch<br />Second Magateen, near the Bus Park</p><a className="text-link" href="https://maps.google.com/?q=Thongping%2C+Suk+Wewe%2C+Juba%2C+South+Sudan" target="_blank" rel="noreferrer">Find us on the map <ArrowUpRight size={15} /></a></div><div className="visit-image"><img src="/images/warm-portrait.jpeg" loading="lazy" alt="A warm, cinematic portrait from V.I.P Creative Studio" /><span className="photo-stamp">JUBA, SS<br />06° 48′ N</span></div></section>
      </main>
      <footer className="site-footer">
        <div className="footer-top">
          <a className="brand" href="#home"><span className="brand-mark"><Aperture size={21} /></span><span className="brand-name"><span className="brand-title">V.I.P CREATIVE STUDIO</span><span className="brand-owner">Stephen Kuol</span></span></a>
          <p>Let Light Leads the Lens.</p>
          <a className="footer-book" href="#booking">Let’s make it yours <ArrowUpRight size={15} /></a>
        </div>
        <div className="footer-contacts" aria-label="Contact and social details">
          <a href={WHATSAPP} target="_blank" rel="noreferrer"><span>WHATSAPP</span><strong>+211 922 865 522</strong></a>
          <a href="mailto:Kuolstephen54@gmail.com"><span>EMAIL</span><strong>Kuolstephen54@gmail.com</strong></a>
          <a href="https://www.tiktok.com/@kuolvip?is_from_webapp=1&amp;sender_device=pc" target="_blank" rel="noreferrer"><span>TIKTOK</span><strong>@kuolvip</strong></a>
          <a href="https://web.facebook.com/kuollonydeang/reels/" target="_blank" rel="noreferrer"><span>FACEBOOK</span><strong>View my Reels</strong></a>
        </div>
        <div className="footer-bottom"><span>© {year} V.I.P Creative Studio · Juba, South Sudan</span>{API && <a href="/admin" className="admin-link">Studio access</a>}</div>
        <p className="developer-credit">Developed by Joseph Bigoah Puok Ruop</p>
      </footer>
      <a className="mobile-booking" href="#booking"><MessageCircle size={17} /> Book your session</a>
    </>
  );
}

export default function App() {
  return API && window.location.pathname.replace(/\/$/, "") === "/admin" ? <AdminDashboard /> : <Site />;
}
